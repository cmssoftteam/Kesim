<?xml version="1.0" encoding="UTF-8"?>
<Root LangModule="ailgcode" Version="1.0">

<!--****************************************************************************
    *
    *  Additional definitions for the G-code B&R language
    *
    ****************************************************************************-->

</Root>